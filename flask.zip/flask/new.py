#importing
from flask import Flask, render_template, request

# interaction
web = Flask(__name__)
#mapping
@web.route('/')
@web.route('/register')

#inputs
def homepage():
    return render_template('register.html')


@web.route('/configration' , methods=['POST' , 'GET'])

def register():
    if request.method=="POST":
        n = request.form.get('name')
        c = request.form.get('city')
        p = request.form.get('phone number')
        return render_template('confirm.html',name=n, city=c, phonenumber=p)
# mains
if __name__=="__main__":
    web.run(debug=True)

